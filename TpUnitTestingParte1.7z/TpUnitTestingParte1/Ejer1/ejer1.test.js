
const {authPin}=require('./ejer1')

test('Comprobar que el programa puede detectar caracteres',()=>{
    expect(authPin("12a4")).toBe(false)
})
test('Comprobar que el programa puede detectar PINS de 7 digitos',()=>{
    expect(authPin(1234567)).toBe(false)
})
test('Comprobar que el programa puede detectar PINS de 3 digitos',()=>{
    expect(authPin(123)).toBe(false)
})
test('Comprobar que el programa acepta PINS de 4 digitos o mas',()=>{
    expect(authPin("12123")).toBe(false)
})
test('Comprobar que el programa acepta caracteres especiales',()=>{
    expect(authPin("32$4")).toBe(true)
})