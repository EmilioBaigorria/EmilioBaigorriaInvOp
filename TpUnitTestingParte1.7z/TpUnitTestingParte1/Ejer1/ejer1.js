/*
1. Validar código PIN
Los bancos utilizan un código PIN numérico como parte de la autenticación de los usuarios. Dicho PIN debe cumplir con los siguientes requerimientos:

PIN de exáctamente 4 o 6 dígitos.
No puede contener letras.
La función debe retornar Verdadero si es el PIN es válido, caso contrario Falso.
*/
function checkLength(PIN){
    if(PIN.length == 4 || PIN.length == 6){
        return true
    }else{
        return false
    }
}
function checkCharacters(PIN){
    let charsArr=["a","b","c","d","e","f","g","h","i","j","k","l","m","n","ñ","o","p","q","r","s","t","u","v","w","x","y","z"]
    for(let i=0;i<PIN.length;i++){
        for(let p=0;p<charsArr.length;p++){
            if(PIN.charAt(i)==charsArr[p]){
                return false
            }
        }
    }
    return true
}
function authPin(PIN){

    if(checkLength(PIN.toString().toLowerCase()) && checkCharacters(PIN.toString().toLowerCase())){
        return true
    }else{
        return false
    }

}

module.exports={authPin}


