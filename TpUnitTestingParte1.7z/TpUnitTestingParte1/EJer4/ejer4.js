/*
4. Calcular el Siglo
Se necesita una función que recibe un valor de año y devuelva el Siglo correspondiente.

1705 --> 18
1900 --> 19
1601 --> 17
*/
function getCentury(year){
    let newYear=year.toString()
    if(newYear.length!==4 || year<0 || typeof year !== "number"){
        return "Año no valido"
    }
    if(newYear.charAt(2) == "0" && newYear.charAt(3)=="0"){
        return `Siglo ${newYear.charAt(0)+newYear.charAt(1)}`
    }else{
        return `Siglo ${Number(newYear.charAt(0)+newYear.charAt(1))+1}`
    }
    
}
module.exports={getCentury}
