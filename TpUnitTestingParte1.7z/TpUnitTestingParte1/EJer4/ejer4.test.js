const {getCentury}=require('./ejer4')

test('Comprobar que el programa acepta años invalidos(Numeros de mas)',()=>{
    expect(getCentury(170132)).toBe("Año no valido")
})

test('Comprobar que el programa acepta años invalidos(Numero negativo)',()=>{
    expect(getCentury(-123)).toBe("Año no valido")
})

test('Comprobar que el programa acepta validos',()=>{
    expect(getCentury(1976)).toBe("Siglo 20")
})

test('Comprobar que el programa acepta años invalidos(Letras)',()=>{
    expect(getCentury("amar")).toBe("Año no valido")
})

test('Comprobar que el programa acepta años invalidos(Mezcla numeros y letras)',()=>{
    expect(getCentury(12+"bf")).toBe("Año no valido")
})
