const {tankVolume}=require('./ejer2')

test('Comprobar funcionamiento basico',()=>{
    expect(tankVolume("12 m","5 m")).toBe(565200)
})

test('Comprobar si recibe argumentos con diferentes',()=>{
    expect(tankVolume("12 cm","5 m")).toBe(56.5)
})

test('Comprobar si el programa detecta diametros negativas',()=>{
    expect(tankVolume("-12 cm","5 m")).toBe("Numero no valido")
})

test('Comprobar si el programa detecta alturas negativas',()=>{
    expect(tankVolume("12 cm","-5 m")).toBe("Numero no valido")
})

test('Comprobar si el programa rechaza letras',()=>{
    expect(tankVolume("bb cm","b m")).toBe("Letras no son validas")
})