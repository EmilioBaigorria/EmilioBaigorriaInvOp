/*
2. Volúmen de un Tanque de Agua
En una fábrica de tanques de agua en acero y inoxidable necesitan calcular de forma rápida el volúmen de los tanques. Dados el diámetro y la altura retornar el volúmen. La función debe cumplir con los siguientes requerimientos:

El resultado debe ser expresado en litros.
Los datos de entrada pueden ser en cm o en m.
π r² h
*/
function curateData(base){

    let baseData=base.toLowerCase()

    let value=""
    let format=""

    let lever=0
    for(let i=0;i<baseData.length;i++){
        if(baseData.charAt(i)==" "){
            lever++
            continue
        }
        if(lever==0){
            value=value.concat(baseData.charAt(i))
        }else{
            format=format.concat(baseData.charAt(i))
        }
    }
    if(format=="cm"){
        return Number.parseFloat(value)*0.01
    }else{
        return Number.parseFloat(value)
    }
    
}
function tankVolume(diameter,heigth){
    let radius=curateData(diameter)/2
    let numHeigth=curateData(heigth)
    if(isNaN(radius) || isNaN(numHeigth)){
        return "Letras no son validas"
    }
    if(radius<0 || numHeigth<0){
        return "Numero no valido"
    }
    let volume=3.14*radius*radius*numHeigth

    return Number.parseFloat((volume*1000).toFixed(1))
}
module.exports={tankVolume}