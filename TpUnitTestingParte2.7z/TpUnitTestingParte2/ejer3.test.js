/*
Franco sabe que es importante mantenerse hidratado, toma 0,5 litros de agua por hora de pedaleo. Dado el timpo Franco está pedaleando, 
calcular la cantidad de agua, en litros, que Franco va a tomar.

Redondea el valor al número mas bajo.
Ejemplos:
Tiempo = 3 --> litros = 1
Tiempo = 6.7 --> litros = 3
Tiempo = 11.8 --> litros = 5
*/
{
    function lPerH(time){
        if(isNaN(time) || typeof time!="number"){
            return "Debe ingresar un numero"
        }
        return `Tiempo=${time}-->litros=${Math.trunc(time*0.5)}`
    }
    //Comigo comentado para pruebas en web
    //const userRep=prompt("¿Cuantas horas pedalea Franco?")
    //console.log(lPerH(Number.parseFloat(userRep)))
    //alert(lPerH(Number.parseFloat(userRep)))
    
}

test('Prueba de funcionamiento basico',()=>{
    expect(lPerH(3)).toBe("Tiempo=3-->litros=1")
})
test('Comprobar que le programa reconoce y rechaza strings',()=>{
    expect(lPerH("Hola mundo")).toBe("Debe ingresar un numero")
})
test('Comprobar que el programa reconoce NaN',()=>{
    expect(lPerH(parseInt("Hola mundo"))).toBe("Debe ingresar un numero")
})
test('Comprobar que el programa opera correctamente con floats',()=>{
    expect(lPerH(6.7)).toBe("Tiempo=6.7-->litros=3")
})
test('Comprobar que reconoce y rechaza booleans',()=>{
    expect(lPerH(true)).toBe("Debe ingresar un numero")
})