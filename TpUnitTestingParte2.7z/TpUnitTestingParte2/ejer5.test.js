{
    function rockPaperScissor(player1,plater2){
        if(typeof player1!=="string" || typeof plater2!=="string"){
            return "Uno de los valores no es valido"
        }
        player1=player1.toLocaleLowerCase()
        plater2=plater2.toLocaleLowerCase()
        switch (player1) {
            //Caso jugardor 1 piedra
            case "piedra":
                switch (plater2) {
                    case "papel":
                        return "¡El jugador 2 gana!"
                        
                    case "tijeras":
                        return "¡El jugador 1 gana!"
                    default:
                        return "¡Empate!"
                    
                    }
                break;
                //Caso jugardor 1 papel
            case "papel":
                switch (plater2) {
                    case "piedra":
                        return "¡El jugador 1 gana!"
                        
                    case "tijeras":
                        return "¡El jugador 2 gana!"
                    default:                            
                        return "¡Empate!"
                        
                    }
                break;
                //Caso jugardor 1 tijeras
            case "tijeras":
                switch (plater2) {
                    case "piedra":
                        return "¡El jugador 2 gana!"
                            
                        case "papel":
                            return "¡El jugador 1 gana!"
                        default:
                            return "¡Empate!"
                        
                    }
                break;
        
            default:
                return "Ocurrio un error"
                break;
        }
    }
}

test('Prueba de funcionamiento basico',()=>{
    expect(rockPaperScissor("piedra","tijeras")).toBe("¡El jugador 1 gana!")
})
test('Comprobar si el programa puede manejar mayusculas',()=>{
    expect(rockPaperScissor("piEDrA","TijERas")).toBe("¡El jugador 1 gana!")
})
test('Comprobar que el programa identifica numeros',()=>{
    expect(rockPaperScissor(2,"tijeras")).toBe("Uno de los valores no es valido")
})
test('Comprobar el programa identifica NaN',()=>{
    expect(rockPaperScissor(0/0,"tijeras")).toBe("Uno de los valores no es valido")
})
test('Prueba de empate',()=>{
    expect(rockPaperScissor("tijeras","tijeras")).toBe("¡Empate!")
})