/* 
6. Validador de Direcciones (Entrega en parte 2)
Una distribuidora necesita validar las direcciones enviadas por los clientes antes de enviar el repartidor. 
Se les pide crear un validador de direcciones que vienen en formato JSON según los siguientes requerimientos:

Una Dirección debe contener los siguientes campos:

Field	        Required	Type
street	        yes	        string
number	        yes	        number
floor_apartment	no	        string
zip_code	    yes	        number
town	        no	        string
city	        yes	        string
province	    yes	        string

*/
{
    function validateAdress(adress){     
        if(typeof adress!=="object"){
            return "La direccion no es un objeto"
        }
        if(adress.street && adress.number && adress.zip_code && adress.city && adress.province){
            return "Direccion valida"
        }else{
            return "Direccion no valida"
        }
    }
}

test('Prueba de funcionamiento basico',()=>{
    expect(validateAdress(
        {
            "street": "Salta",
            "number": 359,
            "floor_apartment": "D3",
            "zip_code": 5500,
            "town": "",
            "city": "Mendoza",
            "province": "Mendoza"
        }
    )).toBe("Direccion valida")
})
test('Comprobar si el programa identifica la falta del campo town',()=>{
    expect(validateAdress(
        {
            "street": "Salta",
            "number": 359,
            "floor_apartment": "D3",
            "zip_code": 5500,
            "city": "Mendoza",
            "province": "Mendoza"
        }
    )).toBe("Direccion valida")
})
test('Comprobra si el programa identifica la falta del campo street ',()=>{
    expect(validateAdress(
        {
            "number": 359,
            "floor_apartment": "D3",
            "zip_code": 5500,
            "town": "",
            "city": "Mendoza",
            "province": "Mendoza"
        }
    )).toBe("Direccion no valida")
})
test('Comprobar si el programa rechaza NaN',()=>{
    expect(validateAdress(
        0/0
    )).toBe("La direccion no es un objeto")
})
test('Comprobar si el programa rechaza tipos de dato diferente a objetos' ,()=>{
    expect(validateAdress(
        "Hola mundo"
    )).toBe("La direccion no es un objeto")
})